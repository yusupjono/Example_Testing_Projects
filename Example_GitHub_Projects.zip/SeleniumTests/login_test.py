from selenium import webdriver
from selenium.webdriver.common.by import By

# Установить драйвер (не забудьте скачать ChromeDriver!)
driver = webdriver.Chrome()

try:
    # Открыть сайт
    driver.get("https://example.com")
    
    # Проверить заголовок страницы
    assert "Example Domain" in driver.title
    
    # Пример работы с формой (замените на реальные ID)
    username = driver.find_element(By.ID, "username")
    password = driver.find_element(By.ID, "password")
    login_button = driver.find_element(By.ID, "login")

    # Ввод данных
    username.send_keys("test_user")
    password.send_keys("password123")
    login_button.click()
    
    # Проверить результат
    assert "Dashboard" in driver.title
finally:
    driver.quit()
